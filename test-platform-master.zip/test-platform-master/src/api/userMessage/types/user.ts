export interface pageDetail{
    pageSize: number
    pageNum: number
    datetime: any
    address: string|null;
    username:string|null;
}
export interface userDetail{
    list:{}
}

export interface psData{
    newPs: null|string,
}
