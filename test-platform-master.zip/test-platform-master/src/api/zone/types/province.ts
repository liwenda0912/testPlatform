export interface Province{
    "pageNum": number,
    "pageSize": number,
    "name": null|string,
}