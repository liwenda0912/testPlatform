export interface City{
    "pageNum": number,
    "pageSize": number,
    "provinceid": null|number,
}