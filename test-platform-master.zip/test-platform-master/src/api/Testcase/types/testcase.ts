export  interface TestCase{
    pageNum: number;
    pageSize: number;
    testCaseDriId: number;
    caseTitle: string;
    module: string;
}