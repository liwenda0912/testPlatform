export interface TestCaseDri{
    pageSize: number
    pageNum: number
}