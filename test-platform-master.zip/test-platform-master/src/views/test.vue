<script setup lang="ts">

</script>

<template>
<el-text>ssssssss</el-text>
</template>

<style scoped>

</style>